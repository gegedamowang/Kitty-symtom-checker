'use client';

import { useEffect, useState } from 'react';

export function HelloKitty() {
  const [blink, setBlink] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setBlink(true);
      setTimeout(() => setBlink(false), 200);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="kitty-container">
      <svg
        viewBox="0 0 200 180"
        className="kitty-svg"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Left ear */}
        <polygon points="45,55 30,10 75,40" fill="#FFFFFF" stroke="#FF8FAB" strokeWidth="2" />
        <polygon points="50,48 38,18 70,40" fill="#FFE4EC" />

        {/* Right ear */}
        <polygon points="155,55 170,10 125,40" fill="#FFFFFF" stroke="#FF8FAB" strokeWidth="2" />
        <polygon points="150,48 162,18 130,40" fill="#FFE4EC" />

        {/* Face */}
        <ellipse cx="100" cy="100" rx="65" ry="58" fill="#FFFFFF" stroke="#FF8FAB" strokeWidth="2" />

        {/* Bow - on right ear */}
        <g className="kitty-bow">
          <ellipse cx="152" cy="38" rx="18" ry="12" fill="#FF8FAB" />
          <ellipse cx="172" cy="30" rx="14" ry="10" fill="#FF8FAB" />
          <ellipse cx="172" cy="46" rx="14" ry="10" fill="#FF8FAB" />
          <circle cx="162" cy="38" r="5" fill="#FFC2D4" />
        </g>

        {/* Left eye */}
        <g className={blink ? 'kitty-eye-blink' : 'kitty-eye'}>
          <ellipse cx="78" cy="95" rx="5" ry="6" fill="#4A3728" />
          <ellipse cx="76" cy="93" rx="1.5" ry="2" fill="#FFFFFF" opacity="0.6" />
        </g>

        {/* Right eye */}
        <g className={blink ? 'kitty-eye-blink' : 'kitty-eye'}>
          <ellipse cx="122" cy="95" rx="5" ry="6" fill="#4A3728" />
          <ellipse cx="120" cy="93" rx="1.5" ry="2" fill="#FFFFFF" opacity="0.6" />
        </g>

        {/* Nose */}
        <ellipse cx="100" cy="105" rx="4" ry="3" fill="#FFCC00" />

        {/* Left whiskers */}
        <line x1="35" y1="90" x2="65" y2="98" stroke="#FF8FAB" strokeWidth="1.5" strokeLinecap="round" />
        <line x1="33" y1="100" x2="65" y2="103" stroke="#FF8FAB" strokeWidth="1.5" strokeLinecap="round" />
        <line x1="35" y1="110" x2="65" y2="108" stroke="#FF8FAB" strokeWidth="1.5" strokeLinecap="round" />

        {/* Right whiskers */}
        <line x1="165" y1="90" x2="135" y2="98" stroke="#FF8FAB" strokeWidth="1.5" strokeLinecap="round" />
        <line x1="167" y1="100" x2="135" y2="103" stroke="#FF8FAB" strokeWidth="1.5" strokeLinecap="round" />
        <line x1="165" y1="110" x2="135" y2="108" stroke="#FF8FAB" strokeWidth="1.5" strokeLinecap="round" />

        {/* Blush */}
        <ellipse cx="65" cy="110" rx="10" ry="6" fill="#FFC2D4" opacity="0.5" />
        <ellipse cx="135" cy="110" rx="10" ry="6" fill="#FFC2D4" opacity="0.5" />
      </svg>
    </div>
  );
}
