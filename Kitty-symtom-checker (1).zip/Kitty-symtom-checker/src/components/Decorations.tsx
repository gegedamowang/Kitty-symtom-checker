'use client';

export function Decorations() {
  return (
    <div className="decorations-layer" aria-hidden="true">
      {/* Floating hearts */}
      <div className="deco-heart deco-1">&#x2665;</div>
      <div className="deco-heart deco-2">&#x2665;</div>
      <div className="deco-heart deco-3">&#x2665;</div>
      <div className="deco-heart deco-4">&#x2665;</div>
      <div className="deco-heart deco-5">&#x2665;</div>

      {/* Stars */}
      <div className="deco-star deco-6">&#x2729;</div>
      <div className="deco-star deco-7">&#x2729;</div>
      <div className="deco-star deco-8">&#x2729;</div>
      <div className="deco-star deco-9">&#x2729;</div>

      {/* Polka dots */}
      <div className="deco-dot deco-10" />
      <div className="deco-dot deco-11" />
      <div className="deco-dot deco-12" />
      <div className="deco-dot deco-13" />
      <div className="deco-dot deco-14" />
      <div className="deco-dot deco-15" />
    </div>
  );
}
