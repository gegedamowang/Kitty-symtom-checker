import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Kitty 症状自查小助手',
  description: '可爱的 Hello Kitty 风格症状自查与用药推荐工具，帮你初步分析身体不适',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body className="antialiased">
        {children}
      </body>
    </html>
  );
}
