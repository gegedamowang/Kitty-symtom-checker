'use client';

import { useState, useCallback } from 'react';
import { diseases, commonSymptoms } from '@/data/diseases';
import type { Disease } from '@/data/diseases';
import { HelloKitty } from '@/components/HelloKitty';
import { Decorations } from '@/components/Decorations';

interface MatchResult {
  disease: Disease;
  matchCount: number;
  matchRate: number;
  matchedSymptoms: string[];
}

function matchDiseases(input: string, selectedTags: string[]): MatchResult[] {
  const allSymptoms = [
    ...input.split(/[\s,，、]+/).filter(Boolean),
    ...selectedTags,
  ].map(s => s.trim().toLowerCase());

  if (allSymptoms.length === 0) return [];

  const results: MatchResult[] = [];

  for (const disease of diseases) {
    const matchedSymptoms: string[] = [];
    let matchCount = 0;

    for (const symptom of allSymptoms) {
      for (const keyword of disease.keywords) {
        if (keyword.includes(symptom) || symptom.includes(keyword)) {
          if (!matchedSymptoms.includes(symptom)) {
            matchedSymptoms.push(symptom);
          }
          matchCount++;
          break;
        }
      }
    }

    if (matchCount > 0) {
      const maxPossible = Math.min(allSymptoms.length, disease.keywords.length);
      const matchRate = Math.min(100, Math.round((matchCount / Math.max(maxPossible, 1)) * 100));
      results.push({ disease, matchCount, matchRate: Math.max(matchRate, 10), matchedSymptoms });
    }
  }

  results.sort((a, b) => b.matchCount - a.matchCount);
  return results.slice(0, 3);
}

function HeartBar({ rate }: { rate: number }) {
  const hearts = 5;
  const filled = Math.ceil((rate / 100) * hearts);
  return (
    <div className="flex items-center gap-1">
      {Array.from({ length: hearts }).map((_, i) => (
        <span
          key={i}
          className={`text-lg transition-all duration-300 ${i < filled ? 'heart-filled' : 'heart-empty'}`}
          style={{ animationDelay: `${i * 0.1}s` }}
        >
          {i < filled ? '\u2764' : '\u2661'}
        </span>
      ))}
      <span className="ml-2 text-sm text-[#9B7A8A]">{rate}%</span>
    </div>
  );
}

function LoadingKitty() {
  return (
    <div className="flex flex-col items-center gap-4 py-12">
      <div className="loading-kitty">
        <svg viewBox="0 0 80 72" className="w-20 h-20" xmlns="http://www.w3.org/2000/svg">
          <polygon points="18,22 12,4 30,16" fill="#FFFFFF" stroke="#FF8FAB" strokeWidth="1.5" />
          <polygon points="62,22 68,4 50,16" fill="#FFFFFF" stroke="#FF8FAB" strokeWidth="1.5" />
          <ellipse cx="40" cy="40" rx="26" ry="23" fill="#FFFFFF" stroke="#FF8FAB" strokeWidth="1.5" />
          <ellipse cx="32" cy="38" rx="2" ry="2.5" fill="#4A3728" />
          <ellipse cx="48" cy="38" rx="2" ry="2.5" fill="#4A3728" />
          <ellipse cx="40" cy="43" rx="2" ry="1.5" fill="#FFCC00" />
          <line x1="15" y1="36" x2="27" y2="39" stroke="#FF8FAB" strokeWidth="1" />
          <line x1="14" y1="42" x2="27" y2="42" stroke="#FF8FAB" strokeWidth="1" />
          <line x1="65" y1="36" x2="53" y2="39" stroke="#FF8FAB" strokeWidth="1" />
          <line x1="66" y1="42" x2="53" y2="42" stroke="#FF8FAB" strokeWidth="1" />
          <ellipse cx="58" cy="16" rx="8" ry="5" fill="#FF8FAB" />
          <ellipse cx="66" cy="12" rx="6" ry="4" fill="#FF8FAB" />
          <ellipse cx="66" cy="20" rx="6" ry="4" fill="#FF8FAB" />
        </svg>
      </div>
      <p className="text-[#9B7A8A] text-base animate-pulse"> Kitty 正在帮你分析中...</p>
      <div className="flex gap-2">
        {['*', '*', '*'].map((s, i) => (
          <span key={i} className="loading-star" style={{ animationDelay: `${i * 0.3}s` }}>{s}</span>
        ))}
      </div>
    </div>
  );
}

export default function Home() {
  const [input, setInput] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [results, setResults] = useState<MatchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [expandedDisease, setExpandedDisease] = useState<string | null>(null);

  const toggleTag = useCallback((tag: string) => {
    setSelectedTags(prev =>
      prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]
    );
  }, []);

  const handleSearch = useCallback(() => {
    if (!input.trim() && selectedTags.length === 0) return;
    setLoading(true);
    setShowResults(false);
    setExpandedDisease(null);

    setTimeout(() => {
      const matched = matchDiseases(input, selectedTags);
      setResults(matched);
      setLoading(false);
      setShowResults(true);
    }, 1200);
  }, [input, selectedTags]);

  const handleReset = useCallback(() => {
    setInput('');
    setSelectedTags([]);
    setResults([]);
    setShowResults(false);
    setExpandedDisease(null);
  }, []);

  return (
    <div className="app-wrapper">
      <Decorations />

      <div className="main-content">
        {/* Header with Kitty */}
        <header className="app-header">
          <HelloKitty />
          <h1 className="app-title">Kitty 症状自查小助手</h1>
          <p className="app-subtitle">告诉 Kitty 你哪里不舒服，帮你初步分析~</p>
        </header>

        {/* Search Section */}
        <section className="search-section">
          <div className="search-box">
            <span className="search-icon">
              <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5" stroke="#FF8FAB" strokeWidth="2" strokeLinecap="round">
                <circle cx="11" cy="11" r="8" />
                <path d="M21 21l-4.35-4.35" />
              </svg>
            </span>
            <input
              type="text"
              className="search-input"
              placeholder="输入你的症状，如：头痛 发烧 咳嗽..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            />
          </div>

          {/* Quick Tags */}
          <div className="tags-section">
            <p className="tags-label">常见症状，点击选择：</p>
            <div className="tags-grid">
              {commonSymptoms.map(symptom => (
                <button
                  key={symptom}
                  className={`symptom-tag ${selectedTags.includes(symptom) ? 'symptom-tag-active' : ''}`}
                  onClick={() => toggleTag(symptom)}
                >
                  {symptom}
                </button>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="action-buttons">
            <button
              className="btn-primary"
              onClick={handleSearch}
              disabled={loading || (!input.trim() && selectedTags.length === 0)}
            >
              <span className="btn-icon">&#x1F50D;</span>
              帮我看看
            </button>
            {(input || selectedTags.length > 0) && (
              <button className="btn-secondary" onClick={handleReset}>
                重新选择
              </button>
            )}
          </div>
        </section>

        {/* Loading */}
        {loading && <LoadingKitty />}

        {/* Results */}
        {showResults && !loading && (
          <section className="results-section">
            {results.length === 0 ? (
              <div className="no-result-card">
                <span className="text-4xl mb-3 block">&#x1F63F;</span>
                <p className="text-[#6B4C5A] text-lg font-medium">没有找到匹配的病症</p>
                <p className="text-[#9B7A8A] text-sm mt-2">试试换个关键词描述症状，或者直接去看医生吧~</p>
              </div>
            ) : (
              <>
                <div className="results-header">
                  <span className="results-icon">&#x1F4CB;</span>
                  <h2 className="results-title">分析结果</h2>
                </div>

                {results.map((result, index) => (
                  <div key={result.disease.id} className="result-card" style={{ animationDelay: `${index * 0.15}s` }}>
                    <div className="result-card-header">
                      <div className="result-rank">
                        {index === 0 ? '\u{1F947}' : index === 1 ? '\u{1F948}' : '\u{1F949}'}
                      </div>
                      <div className="result-info">
                        <h3 className="disease-name">{result.disease.name}</h3>
                        <HeartBar rate={result.matchRate} />
                      </div>
                    </div>

                    <p className="disease-desc">{result.disease.description}</p>

                    <div className="matched-symptoms">
                      <span className="mini-label">匹配症状：</span>
                      <div className="matched-tags">
                        {result.matchedSymptoms.map(s => (
                          <span key={s} className="matched-tag">{s}</span>
                        ))}
                      </div>
                    </div>

                    <div className="typical-symptoms">
                      <span className="mini-label">典型症状：</span>
                      <ul className="symptom-list">
                        {result.disease.symptoms.map((s, i) => (
                          <li key={i} className="symptom-item">{s}</li>
                        ))}
                      </ul>
                    </div>

                    {/* Medicine Section */}
                    <button
                      className="btn-expand"
                      onClick={() => setExpandedDisease(
                        expandedDisease === result.disease.id ? null : result.disease.id
                      )}
                    >
                      {expandedDisease === result.disease.id ? '收起用药推荐' : '查看用药推荐 \u{1F48A}'}
                      <span className={`expand-arrow ${expandedDisease === result.disease.id ? 'expanded' : ''}`}>&#x25BC;</span>
                    </button>

                    {expandedDisease === result.disease.id && (
                      <div className="medicine-section">
                        {result.disease.medicines.map((med, i) => (
                          <div key={i} className="medicine-card">
                            <div className="medicine-header">
                              <span className="medicine-icon">&#x1F48A;</span>
                              <h4 className="medicine-name">{med.name}</h4>
                            </div>
                            <div className="medicine-details">
                              <div className="medicine-row">
                                <span className="medicine-label">用途</span>
                                <span className="medicine-value">{med.usage}</span>
                              </div>
                              <div className="medicine-row">
                                <span className="medicine-label">用法</span>
                                <span className="medicine-value">{med.dosage}</span>
                              </div>
                              <div className="medicine-row medicine-warning">
                                <span className="medicine-label">注意</span>
                                <span className="medicine-value">{med.precautions}</span>
                              </div>
                            </div>
                          </div>
                        ))}

                        {/* See Doctor Warnings */}
                        <div className="see-doctor-card">
                          <div className="see-doctor-header">
                            <span>&#x26A0;&#xFE0F;</span>
                            <span className="see-doctor-title">以下情况请尽快就医</span>
                          </div>
                          <ul className="see-doctor-list">
                            {result.disease.seeDoctor.map((item, i) => (
                              <li key={i} className="see-doctor-item">{item}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </>
            )}

            {/* Disclaimer */}
            <div className="disclaimer-card">
              <div className="disclaimer-icon">&#x1F4AC;</div>
              <div>
                <p className="disclaimer-title">温馨提示</p>
                <p className="disclaimer-text">
                  本工具仅供参考，不能替代专业医生的诊断和治疗。如症状严重或持续不缓解，请及时前往医院就诊。用药前请仔细阅读说明书或咨询药师。
                </p>
              </div>
            </div>
          </section>
        )}

        {/* Footer */}
        <footer className="app-footer">
          <p>Made with &#x2764;&#xFE0F; by Kitty Health Assistant</p>
        </footer>
      </div>
    </div>
  );
}
